import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowUpRight, 
  Github, 
  Twitter, 
  Linkedin, 
  Smartphone,
  Code2,
  Zap,
  Layers,
  ArrowRight
} from 'lucide-react';

const projects = [
  {
    id: "01",
    title: "NEON DASH",
    tags: ["FLUTTER", "WEB3"],
    image: "https://picsum.photos/seed/neon1/800/600",
    color: "#00FF00"
  },
  {
    id: "02",
    title: "CRYPTO FLOW",
    tags: ["DART", "RIVERPOD"],
    image: "https://picsum.photos/seed/neon2/800/600",
    color: "#FF00FF"
  },
  {
    id: "03",
    title: "ZENITH OS",
    tags: ["SYSTEMS", "UI"],
    image: "https://picsum.photos/seed/neon3/800/600",
    color: "#00FFFF"
  },
  {
    id: "04",
    title: "AURA MOBILE",
    tags: ["ANIMATION", "UX"],
    image: "https://picsum.photos/seed/neon4/800/600",
    color: "#FFFF00"
  }
];

export default function App() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen bg-white text-black font-sans selection:bg-[#00FF00] selection:text-black overflow-x-hidden">
      {/* Custom Cursor Follower */}
      <motion.div 
        className="fixed w-8 h-8 bg-[#00FF00] brutal-border rounded-full z-[100] pointer-events-none mix-blend-difference hidden md:block"
        animate={{ x: mousePos.x - 16, y: mousePos.y - 16 }}
        transition={{ type: 'spring', damping: 20, stiffness: 250, mass: 0.5 }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 w-full z-50 p-6 flex justify-between items-center bg-white border-b-4 border-black">
        <div className="text-2xl font-black tracking-tighter uppercase flex items-center gap-2">
          <Zap className="fill-[#00FF00]" />
          <span>NEON.DEV</span>
        </div>
        <div className="hidden md:flex gap-8 font-bold uppercase text-sm">
          <a href="#work" className="hover:bg-[#00FF00] px-2 transition-colors">Work</a>
          <a href="#about" className="hover:bg-[#00FF00] px-2 transition-colors">About</a>
          <a href="#contact" className="hover:bg-[#00FF00] px-2 transition-colors">Contact</a>
        </div>
        <button className="bg-black text-white px-6 py-2 font-bold uppercase tracking-widest brutal-shadow hover:translate-x-[-4px] hover:translate-y-[-4px] transition-all">
          Hire Me
        </button>
      </nav>

      {/* Hero Section */}
      <section className="pt-40 pb-20 px-6 border-b-4 border-black overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="bg-[#00FF00] brutal-border px-4 py-1 font-black uppercase text-sm mb-8 inline-block brutal-shadow">
              Senior Flutter Developer
            </span>
            <h1 className="text-[12vw] md:text-[10vw] font-black leading-[0.85] tracking-tighter uppercase mb-12">
              I BUILD<br/>
              <span className="text-stroke">DIGITAL</span><br/>
              WEAPONS.
            </h1>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-end">
            <p className="text-2xl font-bold leading-tight max-w-lg">
              Specializing in high-performance mobile architectures and custom UI engines that push the boundaries of what's possible on a screen.
            </p>
            <div className="flex justify-end">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
                className="w-40 h-40 brutal-border rounded-full flex items-center justify-center bg-[#00FF00] brutal-shadow"
              >
                <ArrowUpRight size={64} />
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Marquee Section */}
      <div className="bg-black text-white py-6 border-b-4 border-black overflow-hidden">
        <div className="marquee-track">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="flex items-center gap-8 px-8">
              <span className="text-4xl font-black uppercase tracking-tighter">FLUTTER</span>
              <Zap className="text-[#00FF00]" />
              <span className="text-4xl font-black uppercase tracking-tighter">DART</span>
              <Zap className="text-[#00FF00]" />
              <span className="text-4xl font-black uppercase tracking-tighter">FIREBASE</span>
              <Zap className="text-[#00FF00]" />
              <span className="text-4xl font-black uppercase tracking-tighter">UI/UX</span>
              <Zap className="text-[#00FF00]" />
            </div>
          ))}
        </div>
      </div>

      {/* Work Section - Bento Grid */}
      <section id="work" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-8">
          <h2 className="text-8xl font-black tracking-tighter uppercase leading-none">
            SELECTED<br/>WORKS
          </h2>
          <p className="font-mono text-sm uppercase opacity-50 max-w-xs">
            A collection of mobile applications focused on performance, scalability, and custom animation engines.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {projects.map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`brutal-border brutal-shadow-hover transition-all p-6 group cursor-pointer bg-white ${
                i === 0 ? 'md:col-span-8 md:row-span-2' : 
                i === 1 ? 'md:col-span-4' : 
                i === 2 ? 'md:col-span-4' : 
                'md:col-span-12'
              }`}
            >
              <div className="flex justify-between items-start mb-6">
                <span className="font-mono text-xl font-black">{project.id}</span>
                <div className="flex gap-2">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-[10px] font-bold border-2 border-black px-2 py-0.5 uppercase">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="relative aspect-video overflow-hidden brutal-border mb-6">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors" />
              </div>

              <div className="flex justify-between items-center">
                <h3 className="text-4xl font-black tracking-tighter uppercase">{project.title}</h3>
                <div className="w-12 h-12 brutal-border rounded-full flex items-center justify-center group-hover:bg-[#00FF00] transition-colors">
                  <ArrowRight size={24} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-[#00FF00] border-y-4 border-black">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-24 items-center">
          <div className="space-y-12">
            <h2 className="text-8xl font-black tracking-tighter uppercase leading-[0.8]">
              THE<br/>TECH<br/>STACK
            </h2>
            <div className="grid grid-cols-2 gap-8">
              <div className="brutal-border bg-white p-6 brutal-shadow">
                <Smartphone className="mb-4" size={32} />
                <h4 className="font-black uppercase mb-2">Mobile</h4>
                <p className="text-sm font-bold opacity-60">Flutter, Dart, Swift, Kotlin</p>
              </div>
              <div className="brutal-border bg-white p-6 brutal-shadow">
                <Layers className="mb-4" size={32} />
                <h4 className="font-black uppercase mb-2">State</h4>
                <p className="text-sm font-bold opacity-60">Riverpod, Bloc, Redux</p>
              </div>
              <div className="brutal-border bg-white p-6 brutal-shadow">
                <Code2 className="mb-4" size={32} />
                <h4 className="font-black uppercase mb-2">Backend</h4>
                <p className="text-sm font-bold opacity-60">Firebase, Node.js, GraphQL</p>
              </div>
              <div className="brutal-border bg-white p-6 brutal-shadow">
                <Zap className="mb-4" size={32} />
                <h4 className="font-black uppercase mb-2">Tools</h4>
                <p className="text-sm font-bold opacity-60">CI/CD, Codemagic, Docker</p>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="brutal-border brutal-shadow overflow-hidden bg-black">
              <img 
                src="https://picsum.photos/seed/dev/800/1000" 
                alt="Developer"
                className="w-full grayscale hover:grayscale-0 transition-all duration-500"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -right-8 bg-white brutal-border p-6 brutal-shadow max-w-xs">
              <p className="font-bold italic">
                "I don't just write code. I build experiences that people actually enjoy using."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <footer id="contact" className="py-32 px-6 bg-black text-white text-center overflow-hidden">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
        >
          <span className="text-[#00FF00] font-mono uppercase tracking-widest mb-8 block">Ready to start?</span>
          <h2 className="text-[15vw] font-black tracking-tighter uppercase leading-none mb-12 hover:text-[#00FF00] transition-colors cursor-pointer">
            GET IN<br/>TOUCH
          </h2>
          
          <div className="flex flex-wrap justify-center gap-12 mb-24">
            <a href="#" className="flex items-center gap-2 text-2xl font-black hover:text-[#00FF00] transition-colors">
              TWITTER <ArrowUpRight />
            </a>
            <a href="#" className="flex items-center gap-2 text-2xl font-black hover:text-[#00FF00] transition-colors">
              GITHUB <ArrowUpRight />
            </a>
            <a href="#" className="flex items-center gap-2 text-2xl font-black hover:text-[#00FF00] transition-colors">
              LINKEDIN <ArrowUpRight />
            </a>
          </div>

          <div className="pt-12 border-t-2 border-white/20 flex flex-col md:flex-row justify-between items-center gap-8 font-mono text-sm opacity-40">
            <span>© 2024 NEON STUDIO</span>
            <span>BUILT WITH FLUTTER & PASSION</span>
            <span>SAN FRANCISCO, CA</span>
          </div>
        </motion.div>
      </footer>
    </div>
  );
}
