export interface Experience {
  id: string;
  company: string;
  role: string;
  period: string;
  description: string;
}

export interface Education {
  id: string;
  school: string;
  degree: string;
  year: string;
}

export interface CVData {
  personal: {
    name: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    summary: string;
    avatar?: string;
  };
  experiences: Experience[];
  education: Education[];
  skills: string[];
}

export type TemplateType = 'technical' | 'editorial' | 'minimal' | 'luxury';

export interface CVState {
  data: CVData;
  template: TemplateType;
  accentColor: string;
}
